# 🌍 EasyTrip

## Uruchomienie lokalne

1. Zainstaluj zależności:
   ```bash
   npm install
   ```

2. Uruchom aplikację (frontend + backend razem):
   ```bash
   npm run start-all
   ```

3. Backend działa na [http://localhost:5000](http://localhost:5000)
   Frontend działa na [http://localhost:5173](http://localhost:5173)
